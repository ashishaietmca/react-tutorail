import React, { Component } from 'react';
import axios from 'axios';

class Rosters extends Component {

	constructor(props){
	  super(props);
	  this.state = {
		  res: [],
		  loading: true,
		  today_total: 0,	
		  previous_total: 0  
	  };	 
	  
	}
	
 componentDidMount(){
  		//Getting overDue and today tasks count start
		var self = this;
		axios.post('http://localhost/realtyconnection/dashboardservices/dashboard_roster',{			
			gettotal:true				
		}).then(response =>{			
			if(response.data.today_total != ''){
				self.setState({today_total: response.data.today_total,loading: false});
			}
			if(response.data.previous_total != ''){
				self.setState({previous_total: response.data.previous_total,loading: false});
			}
		}).catch(err =>{
			console.log(err);
		});
		//Getting overDue and today tasks count end
		axios.post('http://localhost/realtyconnection/dashboardservices/dashboard_roster',{			
			duration:'today'				
		}).then(response =>{			
			console.log(response.data.result);
			self.setState({res: response.data.result,loading: false});
			self.setState({result_count: response.data.result.length});
		}).catch(err =>{
			console.log(err);
		});
		
	}
	durationChange(duration) {
		//this.preventDefault();
		var self = this;
		self.setState({loading: true});
		axios.post('http://localhost/realtyconnection/dashboardservices/dashboard_roster',{			
			duration:duration			
		}).then(response =>{
			console.log(response.data.result);
			self.setState({res:response.data.result,loading: false});
			self.setState({result_count: response.data.result.length});
		}).catch(err =>{
			console.log(err);
		});
	}

	render() {
	  
	var divNoneStyle = {display: 'none'};
	let content;
	if (this.state.loading) {
			content = <div>Loading...</div>;
		} else {
			content = this.state.res.map((item, key) =>
			<tr>
				<td>
				<input type="checkbox" id="select1"/>
				<label for="select1"></label>
				</td>
				<td>
				<h5 className="company-title">{item.firstname} {item.lastname}</h5>
				<p className="company-subtitle">{item.current_company}</p>
				</td>
				<td>
				<p className="company-subtitle mrg-b10">Last Touch: {item.record_date}</p>
				<p className="company-subtitle">Next Touch: {item.schedule_call_back}</p>
				</td>
				<td><span className="pipeline-title">{item.pipeline_stage}</span></td>
				<td><span className="volume-title">{item.production_volume}</span> up 10%</td>
				<td><span className="volume-title">{item.production_unit}</span> up 18%</td>
				<td>Lynn Cherpak</td>
				<td>Amanda Cuccia</td>
			</tr>
		);
	}
	return (
		<div className="panel panel-default p-brd-yellow">
		<div className="panel-heading">
		<h4 data-toggle="collapse" data-parent="#accordion" href="#collapse7" className="panel-title expand">
		<div className="right-arrow pull-right pdn-t5"><i className="material-icons right col_444 lh_30">expand_more</i></div>
		<a href="javascript:void(0);">
		<div className="pull-left col-md-11 no-padding">
		<div className="pull-left no-padding text-center">
		<img src="http://localhost/realtyconnection/images/reten.png"/>
		</div>
		<div className="pull-left task-title pdn-t12">
		<label>My Roster</label>
		</div>
		<div className="pull-right pdn-t12 task-link">
		<span className="txtClrBlue"><a href="javascript:void(0);" onClick={() => this.durationChange("today")}>Due Today ({this.state.today_total})</a>, </span>
		<span className="txtClrRed"><a href="javascript:void(0);" onClick={() => this.durationChange("previous")} className="txtClrRed">Overdue ({this.state.previous_total})</a></span>
		</div>
		</div>
		</a>
		</h4>
		<div className="clearfix"></div>
		</div>
		<div id="collapse7" className="panel-collapse collapse">
		<div className="panel-body">
		<div className="mass-contact-cont">
		<div className="left posRelative"> <a href="javascript:void(0)" className="selectAll-dropdown">
		<input type="checkbox" id="selectall"/>
		<label for="selectall"></label>
		<span className="caret-sml" id="selectAllid" data-toggle="dropdown" aria-expanded="false"></span> </a>
		<ul className="head-dropdown-menu select-all" role="menu" style={divNoneStyle}>
		  <li> <a href="javascript:void(0);">None</a> </li>
		  <li> <a href="javascript:void(0);">Current Page</a> </li>
		  <li> <a href="javascript:void(0);">Current Search</a> </li>
		</ul>
		</div>
		<div className="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" className="selectAll-dropdown" id="logActId"> Log <span className="caret-sml"></span> </a>
		<ul className="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
		<li><a className="js-mass-send-email" data-action="email" href="javascript:void(0);">Log 1</a></li>
		<li><a className="js-mass-send-text" data-action="text" href="javascript:void(0);">Log 2</a></li>
		<li><a className="js-mass-apply-label" href="javascript:void(0);">Log 3</a></li>
		</ul>
		</div>
		<div className="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" className="selectAll-dropdown" id="sendActId"> Send <span className="caret-sml"></span> </a>
		<ul className="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
		<li><a className="js-mass-send-email" data-action="email" href="javascript:void(0);">Send 1</a></li>
		<li><a className="js-mass-send-text" data-action="text" href="javascript:void(0);">Send 2</a></li>
		<li><a className="js-mass-apply-label" href="javascript:void(0);">Send 3</a></li>
		</ul>
		</div>
		<div className="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" className="selectAll-dropdown" id="campaignActId"> Campaign <span className="caret-sml"></span> </a>
		<ul className="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
		<li><a className="js-mass-send-email" data-action="email" href="javascript:void(0);">Campaign 1</a></li>
		<li><a className="js-mass-send-text" data-action="text" href="javascript:void(0);">Campaign 2</a></li>
		<li><a className="js-mass-apply-label" href="javascript:void(0);">Campaign 3</a></li>
		</ul>
		</div>
		<div className="left posRelative"> 
		<a href="javascript:void(0)" className="selectAll-dropdown">Add Note</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Reminder</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Action Plan</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Reassign</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Label/Group</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Pipeline</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Ignore</a>
		<a href="javascript:void(0)" className="selectAll-dropdown">Mark as Complete</a>
		</div>
		</div>
		<div className="clearfix"></div>
		<div className="table-responsive">
		<table className="table table-striped task-table">
		<thead>
		 <tr>
			<th scope="col">&nbsp;</th>
			<th scope="col">Name/Company</th>
			<th scope="col">Touches</th>
			<th scope="col">Pipeline</th>
			<th scope="col">Volume</th>
			<th scope="col">Units</th>
			<th scope="col">Referred By</th>
			<th scope="col">Assigned To</th>
		  </tr>
		</thead>
		<tbody>
		{content}
		</tbody>
		</table>
		</div>
		</div>
		</div>
		</div>
	);
	}
}

export default Rosters;
