import React, { Component } from 'react';


class TextReplies extends Component {
	
  render() {
    return (
		<div className="panel panel-default p-brd-blue">
		<div className="panel-heading">
		<h4 data-toggle="collapse" data-parent="#accordion" href="#collapse1" className="panel-title expand">
		 <div className="right-arrow pull-right pdn-t5"><i className="material-icons right col_444 lh_30">expand_more</i></div>
		  <a href="javascript:void(0);">
		   </a><div className="pull-left col-md-11 no-padding"><a href="javascript:void(0);">
		   <div className="pull-left no-padding text-center">
		   <img src="http://localhost/realtyconnection/images/textReplies.png"/>
		   </div>
		   <div className="pull-left task-title pdn-t12">
		   <label>Text Replies (18 contacts)</label>
		   </div>
		   </a><div className="pull-right pdn-t12 task-link"><a href="javascript:void(0);">
		   </a><a href="javascript:void(0);">Replied Today</a>
		   <a href="javascript:void(0);">Replied Yesterday</a>
		   <a href="javascript:void(0);">Older Pending Replies</a>
		   </div>
		   </div>
		</h4>
		<div className="clearfix"></div>
		</div>
		<div id="collapse1" className="panel-collapse collapse">
		<div className="panel-body">
		<div className="messgae_tabs">
		<ul className="nav nav-tabs" role="tablist" id="myTabs">
		<li role="presentation" className="active"><a href="javascript:void(0);" aria-controls="#home" role="tab" data-toggle="tab">New Text Replies</a></li>
		<li role="presentation"> <a href="javascript:void(0);" aria-controls="#active-conversations" role="tab" data-toggle="tab">Active Conversations</a></li> 
		<li role="presentation"><a href="javascript:void(0);" aria-controls="#archive-conversations" role="tab" data-toggle="tab">Archive Conversations</a></li>
		</ul>
		<div className="tab-content">
		<div role="tabpanel" className="tab-pane active" id="home">
		<form name="messagecenter" method="POST">   
		<div className="left posRelative wd315">
		<textarea name="message" id="" className="top_txtarea" placeholder="Message"></textarea>
		</div> 
		<div className="left posRelative wd215 mrg_left-15">
		<input name="agentName" id="" type="text" className="" value="" placeholder="Agent Name"/>
		</div>
		<div className="left posRelative wd215 mrg_left-15">
		<input name="txtNumber" id="" type="text" className="" value="" placeholder="Number"/>
		</div>
		<div className="left posRelative wd215 mrg_left-15">
		<div className="reminderDate wd100">
		<input className="datepicker" name="txtDate" id="txtDate" type="text" value="" placeholder="Message Date"/>
		<i className="fa fa-calendar active" id="schedule_icn" aria-hidden="true"></i>
		</div>
		</div>
		<div className="left posRelative mrg_left-15">
		<button type="submit" className="quickFldMore" title="Search" id="showMoreDrop">Search</button>
		</div>
		</form>  
		<div className="clearfix"></div>
		<div className="table-responsive">
		<table className="table table-striped task-table">
		<thead>
		  <tr>
			<th scope="col">Sr.No</th>
			<th scope="col">Agent name</th>
			<th scope="col">Original Message</th>
			<th scope="col">Number</th>
			<th scope="col">Message Date / Time</th>
			<th scope="col">Last Replied date</th>
		  </tr>
		</thead>
		<tbody>
		  <tr>
			<td>1</td>
			<td><a href="javascript:void(0);">Amanda Cuccia Ortiz</a></td>
			<td>Hi Sir, How r u Regards, Nitesh</td>
			<td>+919335903826</td>
			<td>Jun-12-2018 12:20:23</td>
			<td>Jan-03-2019 07:06:11</td>
		  </tr>
		  <tr>
			<td>2</td>
			<td><a href="javascript:void(0);">Amanda Cuccia Ortiz</a></td>
			<td>Hi Sir, How r u Regards, Nitesh</td>
			<td>+919335903826</td>
			<td>Jun-12-2018 12:20:23</td>
			<td>Jan-03-2019 07:06:11</td>
		  </tr>
		  <tr>
			<td>3</td>
			<td><a href="javascript:void(0);">Amanda Cuccia Ortiz</a></td>
			<td>Hi Sir, How r u Regards, Nitesh</td>
			<td>+919335903826</td>
			<td>Jun-12-2018 12:20:23</td>
			<td>Jan-03-2019 07:06:11</td>
		  </tr>
		</tbody>
		</table>
		</div>
		</div>
		<div role="tabpanel" className="tab-pane" id="active-conversations">coming soon</div>
		<div role="tabpanel" className="tab-pane" id="archive-conversations">coming soon</div>
		</div>
		<div className="clearfix"></div>
		</div>
		</div>
		</div>
		</div>
	);
  }
}

export default TextReplies;
