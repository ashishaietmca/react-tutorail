import React, { Component } from 'react';
import axios from 'axios';

class Tasks extends Component {

	constructor(props){
	  super(props);
	  this.state = {
		  res: [],
		  loading: true,
		  today_total: 0,	
		  previous_total: 0  
	  };	 
	  
	}

  	componentDidMount(){
  		//Getting overDue and today tasks count start
		var self = this;
		axios.post('http://localhost/realtyconnection/dashboardservices/dashboard_tasks',{			
			gettotal:true				
		}).then(response =>{			
			if(response.data.today_total != ''){
				self.setState({today_total: response.data.today_total,loading: false});
			}
			if(response.data.previous_total != ''){
				self.setState({previous_total: response.data.previous_total,loading: false});
			}
		}).catch(err =>{
			console.log(err);
		});
		//Getting overDue and today tasks count end
		axios.post('http://localhost/realtyconnection/dashboardservices/dashboard_tasks',{			
			duration:'today'				
		}).then(response =>{			
			console.log(response.data.result);
			self.setState({res: response.data.result,loading: false});
			self.setState({result_count: response.data.result.length});
		}).catch(err =>{
			console.log(err);
		});
		
	}
	durationChange(duration) {
		//this.preventDefault();
		var self = this;
		self.setState({loading: true});
		axios.post('http://localhost/realtyconnection/dashboardservices/dashboard_tasks',{			
			duration:duration			
		}).then(response =>{
			console.log(response.data.result);
			self.setState({res:response.data.result,loading: false});
			self.setState({result_count: response.data.result.length});
		}).catch(err =>{
			console.log(err);
		});
	}

	render() {
	  
	var divNoneStyle = {display: 'none'};
	let content;
	if (this.state.loading) {
			content = <div>Loading...</div>;
		} else {
			content = this.state.res.map((item, key) =>
			<tr>
				<td>
				<input type="checkbox" id="select1"/>
				<label for="select1"></label>
				</td>
				<td>
				<h5 class="company-title">{item.firstname} {item.lastname}</h5>
				<p class="company-subtitle">{item.current_company}</p>
				</td>
				<td>
				<p class="company-subtitle mrg-b10">Last Touch: {item.record_date}</p>
				<p class="company-subtitle">Next Touch: {item.schedule_call_back}</p>
				</td>
				<td><span class="pipeline-title">{item.pipeline_stage}</span></td>
				<td><span class="volume-title">{item.production_volume}</span> up 10%</td>
				<td><span class="volume-title">{item.production_unit}</span> up 18%</td>
				<td>Lynn Cherpak</td>
				<td>Amanda Cuccia</td>
			</tr>
		);
	}
	return (
		<div class="panel panel-default p-brd-yellow">
		<div class="panel-heading">
		<h4 data-toggle="collapse" data-parent="#accordion" href="#collapse3" class="panel-title expand">
		<div class="right-arrow pull-right pdn-t5"><i class="material-icons right col_444 lh_30">expand_more</i></div>
		<a href="#">
		<div class="pull-left col-md-11 no-padding">
		<div class="pull-left no-padding text-center">
		<img src="http://localhost/realtyconnection/images/dueReminder.png"/>
		</div>
		<div class="pull-left task-title pdn-t12">
		<label>Tasks and Reminders (Manually Scheduled)</label>
		</div>
		<div class="pull-right pdn-t12 task-link">
		<span class="txtClrBlue"><a href="javascript:void(0);" onClick={() => this.durationChange("today")}>Due Today ({this.state.today_total})</a>, </span>
		<span class="txtClrRed"><a href="javascript:void(0);" onClick={() => this.durationChange("previous")} class="txtClrRed">Overdue ({this.state.previous_total})</a></span>
		</div>
		</div>
		</a>
		</h4>
		<div class="clearfix"></div>
		</div>
		<div id="collapse3" class="panel-collapse collapse">
		<div class="panel-body">
		<div class="mass-contact-cont">
		<div class="left posRelative"> <a href="javascript:void(0)" class="selectAll-dropdown">
		<input type="checkbox" id="selectall"/>
		<label for="selectall"></label>
		<span class="caret-sml" id="selectAllid" data-toggle="dropdown" aria-expanded="false"></span> </a>
		<ul class="head-dropdown-menu select-all" role="menu" style={divNoneStyle}>
		  <li> <a href="javascript:void(0);">None</a> </li>
		  <li> <a href="javascript:void(0);">Current Page</a> </li>
		  <li> <a href="javascript:void(0);">Current Search</a> </li>
		</ul>
		</div>
		<div class="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" class="selectAll-dropdown" id="logActId"> Log <span class="caret-sml"></span> </a>
		<ul class="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
		<li><a class="js-mass-send-email" data-action="email" href="#">Log 1</a></li>
		<li><a class="js-mass-send-text" data-action="text" href="#">Log 2</a></li>
		<li><a class="js-mass-apply-label" href="#">Log 3</a></li>
		</ul>
		</div>
		<div class="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" class="selectAll-dropdown" id="sendActId"> Send <span class="caret-sml"></span> </a>
		<ul class="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
		<li><a class="js-mass-send-email" data-action="email" href="#">Send 1</a></li>
		<li><a class="js-mass-send-text" data-action="text" href="#">Send 2</a></li>
		<li><a class="js-mass-apply-label" href="#">Send 3</a></li>
		</ul>
		</div>
		<div class="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" class="selectAll-dropdown" id="campaignActId"> Campaign <span class="caret-sml"></span> </a>
		<ul class="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
		<li><a class="js-mass-send-email" data-action="email" href="#">Campaign 1</a></li>
		<li><a class="js-mass-send-text" data-action="text" href="#">Campaign 2</a></li>
		<li><a class="js-mass-apply-label" href="#">Campaign 3</a></li>
		</ul>
		</div>
		<div class="left posRelative"> 
		<a href="javascript:void(0)" class="selectAll-dropdown">Add Note</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Reminder</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Action Plan</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Reassign</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Label/Group</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Pipeline</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Igntore</a>
		<a href="javascript:void(0)" class="selectAll-dropdown">Mark as Complete</a>
		</div>
		</div>
		<div class="clearfix"></div>
		<div class="table-responsive">
		<table class="table table-striped task-table">
		<thead>
		 <tr>
			<th scope="col">&nbsp;</th>
			<th scope="col">Name/Company</th>
			<th scope="col">Touches</th>
			<th scope="col">Pipeline</th>
			<th scope="col">Volume</th>
			<th scope="col">Units</th>
			<th scope="col">Referred By</th>
			<th scope="col">Assigned To</th>
		  </tr>
		</thead>
		<tbody>
		{content}
		</tbody>
		</table>
		</div>
		</div>
		</div>
		</div>
	);
	}
}

export default Tasks;
