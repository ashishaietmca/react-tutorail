import React, { Component } from 'react';
import axios from 'axios';

class Header extends Component {

	constructor(props){
		super(props);
		this.state = {
		  today_date: "",
		  num_reminders: "",
		  num_tasks: "",
		  loading: true	
		}
	}

	componentDidMount(){
		var self = this;
		axios.get('http://localhost/realtyconnection/dashboardservices/head')
		.then(function (response) {
			//response.data.result;
			self.setState({
			today_date: response.data.result.date_val,
			num_reminders: response.data.result.total_reminders,
			num_tasks: response.data.result.total_tasks,
			loading: false
			});
		})
		.catch(function (error) {
		console.log(error);
		});
	}

	render() {
		let content;
		if (this.state.loading) {
			content = <div  className="pull-left like_button_container">
			<h1>Loading..</h1>
			<h6>Today you have <span>0 Reminders Due</span> + <span>0 Tasks Due</span></h6>
			</div>;
		} else { 
			content = <div  className="pull-left like_button_container">
				<h1>{this.state.today_date}</h1>
				<h6>Today you have <span>{this.state.num_reminders} Reminders Due</span> + <span>{this.state.num_tasks} Tasks Due {this.props.data}</span></h6>
				</div>
		}
		
		return (
		<div className="box-header">
		{content}
		</div>
		);
	}
}

export default Header;
