import React, { Component } from 'react';
import axios from 'axios';

class TopSection extends Component {

  constructor(props){
    super(props);
    this.state = {
       daily_rcGoal: 0, daily_rosterGoal: 0, daily_rcCalls: 0,daily_rosterCalls: 0, daily_rcPercent: 0, daily_rosterPercent: 0,
       monthly_rcGoal: 0, monthly_rosterGoal: 0, monthly_rcCalls: 0, monthly_rosterCalls: 0, monthly_rcPercent: 0, monthly_rosterPercent: 0,
       yearly_rcGoal: 0, yearly_rosterGoal: 0, yearly_rcCalls: 0, yearly_rosterCalls: 0, yearly_rcPercent: 0, yearly_rosterPercent: 0,
       listvolume_datacount: 0, listvolume_volume: 0, listvolume_units: 0,
    }
  }

	componentDidMount(){
    var self = this;
    axios.post('http://localhost/realtyconnection/dashboardservices/getDashboardActualCalls',{                 
    }).then(response =>{
      //console.log();
      self.setState({daily_rcGoal: response.data.dailytopStatus.rcGoal, daily_rosterGoal: response.data.dailytopStatus.rosterGoal, daily_rcCalls: response.data.dailytopStatus.rcCalls, daily_rosterCalls: response.data.dailytopStatus.rosterCalls, daily_rcPercent: response.data.dailytopStatus.rcPercent, daily_rosterPercent: response.data.dailytopStatus.rosterPercent ,
                     monthly_rcGoal: response.data.monthlytopStatus.rcGoal, monthly_rosterGoal: response.data.monthlytopStatus.rosterGoal, monthly_rcCalls: response.data.monthlytopStatus.rcCalls, monthly_rosterCalls: response.data.monthlytopStatus.rosterCalls, monthly_rcPercent: response.data.monthlytopStatus.rcPercent, monthly_rosterPercent: response.data.monthlytopStatus.rosterPercent ,
                     yearly_rcGoal: response.data.yearlytopStatus.rcGoal, yearly_rcGoal: response.data.yearlytopStatus.rosterGoal, yearly_rcCalls: response.data.yearlytopStatus.rcCalls, yearly_rosterCalls: response.data.yearlytopStatus.rosterCalls, yearly_rcPercent: response.data.yearlytopStatus.rcPercent, yearly_rosterPercent: response.data.yearlytopStatus.rosterPercent ,  loading: false});
    }).catch(err =>{
      console.log(err);
    });

     axios.post('http://localhost/realtyconnection/dashboardservices/gettopsectionOfdashboard',{                 
    }).then(response =>{      
      self.setState({listvolume_datacount : response.data.count, listvolume_volume : response.data.total_volume, listvolume_units : response.data.total_units, loading: false});
    }).catch(err =>{
      console.log(err);
    });

  }

  render() {
    return (
		
      <div className="top_5section">
        <div className="row mrg-lr_5 top_box-wrap"> 
         
          <div className="col-sm-3 col-part-5 col-xs-12 text-center pad_lr-8"> 
           
            <div className="box box-success box-success-today">
              <div className="box-header with-border">
                <h3 className="box-title text-success">Today</h3>
              </div>
             
              <div className="box-body">
               
                <div className="table-responsive">
                  <table className="table table-condensed">
                    <thead>
                      <tr>
                        <th className="txt_lft">Contacts</th>
                        <th>Actual</th>
                        <th>Goal</th>
                        <th>%</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Recruiting</td>
                        <td id="today_rc_calls_top">{this.state.daily_rcCalls}</td>
                        <td id="today_rc_goal_top">{this.state.daily_rcGoal}</td>
                        <td id="today_rc_percant_top">{this.state.daily_rcPercent}</td>
                      </tr>
                      <tr>
                        <td>Retention</td>
                        <td id="today_roster_calls_top">{this.state.daily_rosterCalls}</td>
                        <td id="today_roster_goal_top">{this.state.daily_rosterGoal}</td>
                        <td id="today_roster_percant_top">{this.state.daily_rosterPercent}</td>
                      </tr>                      
                    </tbody>
                  </table>
                </div>
              
              </div>
             
            </div>
            
          </div>
        
          <div className="col-sm-3 col-part-5 col-xs-12 text-center pad_lr-8"> 
           
            <div className="box box-danger">
              <div className="box-header with-border">
                <h3 className="box-title text-danger">This Month</h3>
              </div>
              
              <div className="box-body">			  
                <div className="table-responsive">
                  <table className="table table-condensed">
                    <thead>
                      <tr>
                        <th className="txt_lft">Contacts</th>
                        <th>Actual</th>
                        <th>Goal</th>
                        <th>%</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Recruiting</td>
                        <td id="monthly_rc_calls_top">{this.state.monthly_rcCalls}</td>
                        <td id="monthly_rc_goal_top">{this.state.monthly_rcGoal}</td>
                        <td id="monthly_rc_percent_top">{this.state.monthly_rcPercent}</td>
                      </tr>
                      <tr>
                        <td>Retention</td>
                        <td id="monthly_roster_calls_top">{this.state.monthly_rosterCalls}</td>
                        <td id="monthly_roster_goal_top"> {this.state.monthly_rosterGoal}</td>
                        <td id="monthly_roster_percant_top"> {this.state.monthly_rosterPercent}</td>
                      </tr>
                     
                    </tbody>
                  </table>
                </div>
               
              </div>
              
            </div>
          
          </div>
         
          <div className="col-sm-3 col-part-5 col-xs-12 text-center pad_lr-8"> 
           
		
            <div className="box box-warning">
              <div className="box-header with-border">
                <h3 className="box-title text-warning">This Year</h3>
              </div>
             
              <div className="box-body">			  
                <div className="table-responsive">
                  <table className="table table-condensed">
                    <thead>
                      <tr>
                        <th className="txt_lft">Contacts</th>
                        <th>Actual</th>
                        <th>Goal</th>
                        <th>%</th>
                      </tr>
                    </thead>
                    <tbody>
                     
                        <tr>
                        <td>Recruiting</td>
                        <td id="yearly_rc_calls_top">{this.state.yearly_rcCalls}</td>
                        <td id="yearly_rc_goal_top">{this.state.yearly_rcGoal}</td>
                        <td id="yearly_rc_percent_top">{this.state.yearly_rcPercent}</td>
                      </tr>
                      <tr>
                        <td>Retention</td>
                        <td id="yearly_roster_calls_top">{this.state.yearly_rosterCalls}</td>
                        <td id="yearly_roster_goal_top">{this.state.yearly_rosterGoal}</td>
                        <td id="yearly_roster_percant_top">{this.state.yearly_rosterPercent}</td>
                      </tr>                     
                    </tbody>
                  </table>
                </div>
               
              </div>
           
            </div>
          
		
          </div>
         
          <div className="col-sm-3 col-part-5 col-xs-12 text-center pad_lr-8"> 
          
			
            <div className="box box-primary">
              <div className="box-header with-border">
                <h3 className="box-title text-primary">Current Pipeline</h3>
              </div>
             
              <div className="box-body">			  
                <div className="table-responsive">
                  <table className="table table-condensed">
                    <thead>
                      <tr>
                        <th>&nbsp;</th>
                        <th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>No. of Agents</td>
                        <td id="listvolume_datacount">{this.state.listvolume_datacount}</td>
                      </tr>
                      <tr>
                        <td>Volume</td>
                        <td id="listvolume_datatotal_volume">{this.state.listvolume_volume}</td>
                      </tr>
                      <tr>
                        <td>No. of transactions</td>
                        <td id="listvolume_datatotal_units">{this.state.listvolume_units}</td>
                      </tr>
                    
                    </tbody>
                  </table>
                </div>
              
              </div>
             
            </div>
          
				
          </div>
         
          <div className="col-sm-3 col-part-5 col-xs-12 text-center pad_lr-8"> 
          
            <div className="box box-info">
              <div className="box-header with-border">
                <h3 className="box-title text-info">Agent Movement This Year</h3>
              </div>
             
              <div className="box-body">
                <div className="table-responsive">
                  <table className="table table-condensed">
                    <thead>
                      <tr>
                        <th>&nbsp;</th>
                        <th>WON</th>
                        <th>LOST</th>
                        <th>NET</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Agents</td>
                        <td>5</td>
                        <td>10</td>
                        <td>-5</td>
                      </tr>
                      <tr>
                        <td>Volume</td>
                        <td>$15M</td>
                        <td>$10M</td>
                        <td>+5M</td>
                      </tr>
                      <tr>
                        <td className="hidebefore1680">No. of <br />transactions</td>
					               <td className="showafter1680">No. of transactions</td>
                        <td>200</td>
                        <td>100</td>
                        <td>+100</td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
                
                <div className="pull-right">Coming Soon</div>
              </div>
             
            </div>
          
          </div>
        </div>
      </div>
    
	);
  }
}

export default TopSection;
