import React, { Component } from 'react';


class ReferralLeads extends Component {
	
  render() {
	  	var divNoneStyle = {
	display: 'none'
	};
	
    return (
		<div className="panel panel-default p-brd-light-green">
					<div className="panel-heading">
					  <h4 data-toggle="collapse" data-parent="#accordion" href="#collapse9" className="panel-title expand">
						<div className="right-arrow pull-right pdn-t5"><i className="material-icons right col_444 lh_30">expand_more</i></div>
						<a href="javascript:void(0);">
						  <div className="pull-left col-md-11 no-padding">
						   <div className="pull-left no-padding text-center">
						   <img src="http://localhost/realtyconnection/images/addTodash.png"/>
						   </div>
						   <div className="pull-left task-title pdn-t12">
						   <label>Referral Loop (Biz Card Leads)</label>
						   </div>
						   <div className="pull-right pdn-t12">
						   <span className="txtClrBlue">Due Today, </span>
						   <span className="txtClrRed">Overdue</span>
						   </div>
						   </div>
						</a>
					  </h4>
					  <div className="clearfix"></div>
					</div>
					<div id="collapse9" className="panel-collapse collapse">
					  <div className="panel-body">
						 <div className="mass-contact-cont">
						  <div className="left posRelative"> <a href="javascript:void(0)" className="selectAll-dropdown">
							<input type="checkbox" id="selectall"/>
							<label for="selectall"></label>
							<span className="caret-sml" id="selectAllid" data-toggle="dropdown" aria-expanded="false"></span> </a>
							<ul className="head-dropdown-menu select-all" role="menu" style={divNoneStyle}>
							  <li> <a href="javascript:void(0);">None</a> </li>
							  <li> <a href="javascript:void(0);">Current Page</a> </li>
							  <li> <a href="javascript:void(0);">Current Search</a> </li>
							</ul>
						  </div>
						<div className="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" className="selectAll-dropdown" id="logActId"> Log <span className="caret-sml"></span> </a>
						  <ul className="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
							<li><a className="js-mass-send-email" data-action="email" href="javascript:void(0);">Log 1</a></li>
							<li><a className="js-mass-send-text" data-action="text" href="javascript:void(0);">Log 2</a></li>
							<li><a className="js-mass-apply-label" href="javascript:void(0);">Log 3</a></li>
						  </ul>
						</div>
						<div className="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" className="selectAll-dropdown" id="sendActId"> Send <span className="caret-sml"></span> </a>
						  <ul className="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
							<li><a className="js-mass-send-email" data-action="email" href="javascript:void(0);">Send 1</a></li>
							<li><a className="js-mass-send-text" data-action="text" href="javascript:void(0);">Send 2</a></li>
							<li><a className="js-mass-apply-label" href="javascript:void(0);">Send 3</a></li>
						  </ul>
						</div>
						<div className="left posRelative"> <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false" className="selectAll-dropdown" id="campaignActId"> Campaign <span className="caret-sml"></span> </a>
						  <ul className="head-dropdown-menu mass-drop" role="menu" style={divNoneStyle}>
							<li><a className="js-mass-send-email" data-action="email" href="javascript:void(0);">Campaign 1</a></li>
							<li><a className="js-mass-send-text" data-action="text" href="javascript:void(0);">Campaign 2</a></li>
							<li><a className="js-mass-apply-label" href="javascript:void(0);">Campaign 3</a></li>
						  </ul>
						</div>
						<div className="left posRelative"> 
						  <a href="javascript:void(0)" className="selectAll-dropdown">Add Note</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Reminder</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Action Plan</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Reassign</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Label/Group</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Pipeline</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Igntore</a>
						  <a href="javascript:void(0)" className="selectAll-dropdown">Mark as Complete</a>
						</div>
					</div>
					<div className="clearfix"></div>
						<div className="table-responsive">
					  <table className="table table-striped task-table">
						<thead>
						  <tr>
							<th scope="col">&nbsp;</th>
							<th scope="col">Name/Company</th>
							<th scope="col">Touches</th>
							<th scope="col">Pipeline</th>
							<th scope="col">Volume</th>
							<th scope="col">Units</th>
							<th scope="col">Referred By</th>
							<th scope="col">Assigned To</th>
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td>
							  <input type="checkbox" id="select22"/>
							  <label for="select22"></label>
							</td>
							<td>
							  <h5 className="company-title">Mike Abeyta</h5>
							  <p className="company-subtitle">Coldwell Banker</p>
							</td>
							<td>
							  <p className="company-subtitle mrg-b10">Last Touch: 12/12/2018</p>
							  <p className="company-subtitle">Next Touch: 01/07/2019</p>
							</td>
							<td><span className="pipeline-title">Interviewed</span></td>
							<td><span className="volume-title">$10M</span> up 10%</td>
							<td><span className="volume-title">15</span> up 18%</td>
							<td>Lynn Cherpak</td>
							<td>Amanda Cuccia</td>
						  </tr>
						  <tr>
							<td>
							  <input type="checkbox" id="select23"/>
							  <label for="select23"></label>
							</td>
							<td>
							  <h5 className="company-title">Mike Abeyta</h5>
							  <p className="company-subtitle">Coldwell Banker</p>
							</td>
							<td>
							  <p className="company-subtitle mrg-b10">Last Touch: 12/12/2018</p>
							  <p className="company-subtitle">Next Touch: 01/07/2019</p>
							</td>
							<td><span className="pipeline-title">Interviewed</span></td>
							<td><span className="volume-title">$10M</span> up 10%</td>
							<td><span className="volume-title">15</span> up 18%</td>
							<td>Lynn Cherpak</td>
							<td>Amanda Cuccia</td>
						  </tr>
						  <tr>
							<td>
							  <input type="checkbox" id="select24"/>
							  <label for="select24"></label>
							</td>
							<td>
							  <h5 className="company-title">Mike Abeyta</h5>
							  <p className="company-subtitle">Coldwell Banker</p>
							</td>
							<td>
							  <p className="company-subtitle mrg-b10">Last Touch: 12/12/2018</p>
							  <p className="company-subtitle">Next Touch: 01/07/2019</p>
							</td>
							<td><span className="pipeline-title">Interviewed</span></td>
							<td><span className="volume-title">$10M</span> up 10%</td>
							<td><span className="volume-title">15</span> up 18%</td>
							<td>Lynn Cherpak</td>
							<td>Amanda Cuccia</td>
						  </tr>
						</tbody>
					  </table>
					</div>
					  </div>
					</div>
				  </div>
	);
  }
}

export default ReferralLeads;
