import React, { Component } from 'react';
import './App.css';
import Header from './sub-components/Header.js';
import TextReplies from './sub-components/TextReplies.js';
import Appointments from './sub-components/Appointments.js';
import Tasks from './sub-components/Tasks.js';
import Followings from './sub-components/Followings.js';
import Coops from './sub-components/Coops.js';
import Retentions from './sub-components/Retentions.js';
import Rosters from './sub-components/Rosters.js';
import ReferralLeads from './sub-components/ReferralLeads.js';
import ReferralLoops from './sub-components/ReferralLoops.js';
import Leads from './sub-components/Leads.js';
import Priorities from './sub-components/Priorities.js';
import TopSection from './sub-components/TopSection.js';

class Dash extends Component {
	
  render() {

    return (
		<div>
		<TopSection/>
		<div class="row mrg-lr_5">
			<div class="col-md-12">
			  <div class="month_box quick_module">
				<div class="box box-primary">
				  <Header/>
				  <div class="col-sm-12">
					<div class="panel-group" id="accordion">
					<TextReplies/>
					<Appointments/>
					<Tasks/>
					<Followings/>
					<Coops/>
					<Retentions/>
					<Rosters from/>
					<ReferralLeads/>
					<ReferralLoops/>
					<Leads/>
					<Priorities/>
					</div> 
				  </div>
				  <div class="clearfix"></div>
				</div>
			  </div>
			</div>
		</div>
		</div>

	);
  }
}

export default Dash;
